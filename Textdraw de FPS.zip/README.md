/* Olá, bom gente eu vim trazer essa textdraw de mostrar o FPS do Jogador
Já adianto a vocês que em alguns apks de samp as vezes o FPS não vai
Contar por Ex: eu testei no "SAMP LAUNCHER" e o FPS não contava la
Más bom pra quem for script vocês podem está otimizando mais esse
Sistema e ta podendo usar, a textdraw fica no canto esquerdo do tela */
Um pouco acima em baixo do radar(Mapa).

Lembrando que os créditos são meus.

Discord: Walkerxinho7#9124
Atenciosamente, Walkerxinho7